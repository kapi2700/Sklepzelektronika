/********************************************************************************
** Form generated from reading UI file 'dodaj_towar.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DODAJ_TOWAR_H
#define UI_DODAJ_TOWAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dodaj_towar
{
public:
    QWidget *centralwidget;
    QSplitter *splitter_2;
    QSplitter *splitter;
    QLabel *label;
    QLineEdit *kategoria_txt;
    QLabel *label_2;
    QLineEdit *nazwa_txt;
    QLabel *label_3;
    QLineEdit *cena_txt;
    QLabel *label_4;
    QLineEdit *vat_txt;
    QLabel *label_10;
    QLineEdit *cecha1_txt;
    QLabel *label_9;
    QLineEdit *cecha2_txt;
    QLabel *label_8;
    QLineEdit *cecha3_txt;
    QLabel *label_7;
    QLineEdit *cecha4_txt;
    QLabel *label_6;
    QLineEdit *cecha5_txt;
    QLabel *label_5;
    QLineEdit *opis_txt;
    QSplitter *splitter_3;
    QPushButton *dodaj_btn;
    QPushButton *anuluj_btn;
    QLabel *blad_lbl;

    void setupUi(QWidget *dodaj_towar)
    {
        if (dodaj_towar->objectName().isEmpty())
            dodaj_towar->setObjectName(QString::fromUtf8("dodaj_towar"));
        dodaj_towar->resize(505, 602);
        centralwidget = new QWidget(dodaj_towar);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setGeometry(QRect(0, 0, 501, 601));
        splitter_2 = new QSplitter(centralwidget);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(10, 10, 481, 591));
        splitter_2->setOrientation(Qt::Vertical);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Vertical);
        label = new QLabel(splitter);
        label->setObjectName(QString::fromUtf8("label"));
        splitter->addWidget(label);
        kategoria_txt = new QLineEdit(splitter);
        kategoria_txt->setObjectName(QString::fromUtf8("kategoria_txt"));
        splitter->addWidget(kategoria_txt);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter->addWidget(label_2);
        nazwa_txt = new QLineEdit(splitter);
        nazwa_txt->setObjectName(QString::fromUtf8("nazwa_txt"));
        splitter->addWidget(nazwa_txt);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        cena_txt = new QLineEdit(splitter);
        cena_txt->setObjectName(QString::fromUtf8("cena_txt"));
        splitter->addWidget(cena_txt);
        label_4 = new QLabel(splitter);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter->addWidget(label_4);
        vat_txt = new QLineEdit(splitter);
        vat_txt->setObjectName(QString::fromUtf8("vat_txt"));
        splitter->addWidget(vat_txt);
        label_10 = new QLabel(splitter);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        splitter->addWidget(label_10);
        cecha1_txt = new QLineEdit(splitter);
        cecha1_txt->setObjectName(QString::fromUtf8("cecha1_txt"));
        splitter->addWidget(cecha1_txt);
        label_9 = new QLabel(splitter);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        splitter->addWidget(label_9);
        cecha2_txt = new QLineEdit(splitter);
        cecha2_txt->setObjectName(QString::fromUtf8("cecha2_txt"));
        splitter->addWidget(cecha2_txt);
        label_8 = new QLabel(splitter);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        splitter->addWidget(label_8);
        cecha3_txt = new QLineEdit(splitter);
        cecha3_txt->setObjectName(QString::fromUtf8("cecha3_txt"));
        splitter->addWidget(cecha3_txt);
        label_7 = new QLabel(splitter);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        splitter->addWidget(label_7);
        cecha4_txt = new QLineEdit(splitter);
        cecha4_txt->setObjectName(QString::fromUtf8("cecha4_txt"));
        splitter->addWidget(cecha4_txt);
        label_6 = new QLabel(splitter);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        splitter->addWidget(label_6);
        cecha5_txt = new QLineEdit(splitter);
        cecha5_txt->setObjectName(QString::fromUtf8("cecha5_txt"));
        splitter->addWidget(cecha5_txt);
        label_5 = new QLabel(splitter);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        splitter->addWidget(label_5);
        opis_txt = new QLineEdit(splitter);
        opis_txt->setObjectName(QString::fromUtf8("opis_txt"));
        splitter->addWidget(opis_txt);
        splitter_3 = new QSplitter(splitter);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        dodaj_btn = new QPushButton(splitter_3);
        dodaj_btn->setObjectName(QString::fromUtf8("dodaj_btn"));
        splitter_3->addWidget(dodaj_btn);
        anuluj_btn = new QPushButton(splitter_3);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        splitter_3->addWidget(anuluj_btn);
        splitter->addWidget(splitter_3);
        splitter_2->addWidget(splitter);
        blad_lbl = new QLabel(splitter_2);
        blad_lbl->setObjectName(QString::fromUtf8("blad_lbl"));
        splitter_2->addWidget(blad_lbl);

        retranslateUi(dodaj_towar);

        QMetaObject::connectSlotsByName(dodaj_towar);
    } // setupUi

    void retranslateUi(QWidget *dodaj_towar)
    {
        dodaj_towar->setWindowTitle(QCoreApplication::translate("dodaj_towar", "dodaj_towar", nullptr));
        label->setText(QCoreApplication::translate("dodaj_towar", "Kategoria", nullptr));
        label_2->setText(QCoreApplication::translate("dodaj_towar", "Nazwa", nullptr));
        label_3->setText(QCoreApplication::translate("dodaj_towar", "Cena", nullptr));
        label_4->setText(QCoreApplication::translate("dodaj_towar", "Vat", nullptr));
        label_10->setText(QCoreApplication::translate("dodaj_towar", "Cecha 1", nullptr));
        label_9->setText(QCoreApplication::translate("dodaj_towar", "Cecha 2", nullptr));
        label_8->setText(QCoreApplication::translate("dodaj_towar", "Cecha 3", nullptr));
        label_7->setText(QCoreApplication::translate("dodaj_towar", "Cecha 4", nullptr));
        label_6->setText(QCoreApplication::translate("dodaj_towar", "Cecha 5", nullptr));
        label_5->setText(QCoreApplication::translate("dodaj_towar", "Opis", nullptr));
        dodaj_btn->setText(QCoreApplication::translate("dodaj_towar", "Dodaj", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("dodaj_towar", "Anuluj", nullptr));
        blad_lbl->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class dodaj_towar: public Ui_dodaj_towar {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DODAJ_TOWAR_H
