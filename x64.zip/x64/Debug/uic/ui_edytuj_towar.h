/********************************************************************************
** Form generated from reading UI file 'edytuj_towar.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDYTUJ_TOWAR_H
#define UI_EDYTUJ_TOWAR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_edytuj_towar
{
public:
    QStackedWidget *stackedWidget;
    QWidget *page;
    QLabel *blad_lbl;
    QSplitter *splitter_2;
    QLabel *label_2;
    QListWidget *dane_do_modyfikacji_list;
    QLabel *label_3;
    QLineEdit *nowa_wartosc_txt;
    QSplitter *splitter;
    QPushButton *edytuj_btn;
    QPushButton *anuluj_btn;
    QWidget *page_2;
    QLabel *blad_lbl2;
    QSplitter *splitter_5;
    QSplitter *splitter_3;
    QLabel *label_4;
    QLabel *ilosc_lbl;
    QLabel *label;
    QLineEdit *ilosc_txt;
    QSplitter *splitter_4;
    QPushButton *edytuj_btn_2;
    QPushButton *anuluj_btn_2;

    void setupUi(QWidget *edytuj_towar)
    {
        if (edytuj_towar->objectName().isEmpty())
            edytuj_towar->setObjectName(QString::fromUtf8("edytuj_towar"));
        edytuj_towar->resize(400, 372);
        stackedWidget = new QStackedWidget(edytuj_towar);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 9, 401, 361));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        blad_lbl = new QLabel(page);
        blad_lbl->setObjectName(QString::fromUtf8("blad_lbl"));
        blad_lbl->setGeometry(QRect(-160, 185, 321, 21));
        splitter_2 = new QSplitter(page);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(10, 10, 381, 331));
        splitter_2->setOrientation(Qt::Vertical);
        label_2 = new QLabel(splitter_2);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter_2->addWidget(label_2);
        dane_do_modyfikacji_list = new QListWidget(splitter_2);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        dane_do_modyfikacji_list->setObjectName(QString::fromUtf8("dane_do_modyfikacji_list"));
        splitter_2->addWidget(dane_do_modyfikacji_list);
        label_3 = new QLabel(splitter_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter_2->addWidget(label_3);
        nowa_wartosc_txt = new QLineEdit(splitter_2);
        nowa_wartosc_txt->setObjectName(QString::fromUtf8("nowa_wartosc_txt"));
        splitter_2->addWidget(nowa_wartosc_txt);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        edytuj_btn = new QPushButton(splitter);
        edytuj_btn->setObjectName(QString::fromUtf8("edytuj_btn"));
        splitter->addWidget(edytuj_btn);
        anuluj_btn = new QPushButton(splitter);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        splitter->addWidget(anuluj_btn);
        splitter_2->addWidget(splitter);
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        blad_lbl2 = new QLabel(page_2);
        blad_lbl2->setObjectName(QString::fromUtf8("blad_lbl2"));
        blad_lbl2->setGeometry(QRect(60, 220, 271, 21));
        splitter_5 = new QSplitter(page_2);
        splitter_5->setObjectName(QString::fromUtf8("splitter_5"));
        splitter_5->setGeometry(QRect(10, 30, 371, 161));
        splitter_5->setOrientation(Qt::Vertical);
        splitter_3 = new QSplitter(splitter_5);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        label_4 = new QLabel(splitter_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter_3->addWidget(label_4);
        ilosc_lbl = new QLabel(splitter_3);
        ilosc_lbl->setObjectName(QString::fromUtf8("ilosc_lbl"));
        splitter_3->addWidget(ilosc_lbl);
        splitter_5->addWidget(splitter_3);
        label = new QLabel(splitter_5);
        label->setObjectName(QString::fromUtf8("label"));
        splitter_5->addWidget(label);
        ilosc_txt = new QLineEdit(splitter_5);
        ilosc_txt->setObjectName(QString::fromUtf8("ilosc_txt"));
        splitter_5->addWidget(ilosc_txt);
        splitter_4 = new QSplitter(splitter_5);
        splitter_4->setObjectName(QString::fromUtf8("splitter_4"));
        splitter_4->setOrientation(Qt::Horizontal);
        edytuj_btn_2 = new QPushButton(splitter_4);
        edytuj_btn_2->setObjectName(QString::fromUtf8("edytuj_btn_2"));
        splitter_4->addWidget(edytuj_btn_2);
        anuluj_btn_2 = new QPushButton(splitter_4);
        anuluj_btn_2->setObjectName(QString::fromUtf8("anuluj_btn_2"));
        splitter_4->addWidget(anuluj_btn_2);
        splitter_5->addWidget(splitter_4);
        stackedWidget->addWidget(page_2);

        retranslateUi(edytuj_towar);

        stackedWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(edytuj_towar);
    } // setupUi

    void retranslateUi(QWidget *edytuj_towar)
    {
        edytuj_towar->setWindowTitle(QCoreApplication::translate("edytuj_towar", "edytuj_towar", nullptr));
        blad_lbl->setText(QString());
        label_2->setText(QCoreApplication::translate("edytuj_towar", "Wybierz dane do modyfikacji:", nullptr));

        const bool __sortingEnabled = dane_do_modyfikacji_list->isSortingEnabled();
        dane_do_modyfikacji_list->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = dane_do_modyfikacji_list->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("edytuj_towar", "nazwa", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = dane_do_modyfikacji_list->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("edytuj_towar", "cena_jednostkowa", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = dane_do_modyfikacji_list->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("edytuj_towar", "stawka_VAT", nullptr));
        QListWidgetItem *___qlistwidgetitem3 = dane_do_modyfikacji_list->item(3);
        ___qlistwidgetitem3->setText(QCoreApplication::translate("edytuj_towar", "cecha_1", nullptr));
        QListWidgetItem *___qlistwidgetitem4 = dane_do_modyfikacji_list->item(4);
        ___qlistwidgetitem4->setText(QCoreApplication::translate("edytuj_towar", "cecha_2", nullptr));
        QListWidgetItem *___qlistwidgetitem5 = dane_do_modyfikacji_list->item(5);
        ___qlistwidgetitem5->setText(QCoreApplication::translate("edytuj_towar", "cecha_3", nullptr));
        QListWidgetItem *___qlistwidgetitem6 = dane_do_modyfikacji_list->item(6);
        ___qlistwidgetitem6->setText(QCoreApplication::translate("edytuj_towar", "cecha_4", nullptr));
        QListWidgetItem *___qlistwidgetitem7 = dane_do_modyfikacji_list->item(7);
        ___qlistwidgetitem7->setText(QCoreApplication::translate("edytuj_towar", "cecha_5", nullptr));
        dane_do_modyfikacji_list->setSortingEnabled(__sortingEnabled);

        label_3->setText(QCoreApplication::translate("edytuj_towar", "Podaj nowa wartosc:", nullptr));
        edytuj_btn->setText(QCoreApplication::translate("edytuj_towar", "Edytuj", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("edytuj_towar", "Anuluj", nullptr));
        blad_lbl2->setText(QString());
        label_4->setText(QCoreApplication::translate("edytuj_towar", "Aktualna ilosc:", nullptr));
        ilosc_lbl->setText(QString());
        label->setText(QCoreApplication::translate("edytuj_towar", "Nowa ilosc:", nullptr));
        edytuj_btn_2->setText(QCoreApplication::translate("edytuj_towar", "Edytuj", nullptr));
        anuluj_btn_2->setText(QCoreApplication::translate("edytuj_towar", "Anuluj", nullptr));
    } // retranslateUi

};

namespace Ui {
    class edytuj_towar: public Ui_edytuj_towar {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDYTUJ_TOWAR_H
