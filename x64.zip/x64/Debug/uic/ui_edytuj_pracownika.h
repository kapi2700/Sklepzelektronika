/********************************************************************************
** Form generated from reading UI file 'edytuj_pracownika.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDYTUJ_PRACOWNIKA_H
#define UI_EDYTUJ_PRACOWNIKA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_edytuj_pracownika
{
public:
    QSplitter *splitter_2;
    QLabel *label_3;
    QListWidget *dane_do_modyfikacji_list;
    QLabel *label_4;
    QLineEdit *nowa_wartosc_txt;
    QSplitter *splitter;
    QPushButton *edytuj_btn;
    QPushButton *anuluj_btn;
    QLabel *blad_lbl;

    void setupUi(QWidget *edytuj_pracownika)
    {
        if (edytuj_pracownika->objectName().isEmpty())
            edytuj_pracownika->setObjectName(QString::fromUtf8("edytuj_pracownika"));
        edytuj_pracownika->resize(400, 312);
        splitter_2 = new QSplitter(edytuj_pracownika);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(10, 10, 381, 270));
        splitter_2->setOrientation(Qt::Vertical);
        label_3 = new QLabel(splitter_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter_2->addWidget(label_3);
        dane_do_modyfikacji_list = new QListWidget(splitter_2);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        new QListWidgetItem(dane_do_modyfikacji_list);
        dane_do_modyfikacji_list->setObjectName(QString::fromUtf8("dane_do_modyfikacji_list"));
        splitter_2->addWidget(dane_do_modyfikacji_list);
        label_4 = new QLabel(splitter_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter_2->addWidget(label_4);
        nowa_wartosc_txt = new QLineEdit(splitter_2);
        nowa_wartosc_txt->setObjectName(QString::fromUtf8("nowa_wartosc_txt"));
        splitter_2->addWidget(nowa_wartosc_txt);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        edytuj_btn = new QPushButton(splitter);
        edytuj_btn->setObjectName(QString::fromUtf8("edytuj_btn"));
        splitter->addWidget(edytuj_btn);
        anuluj_btn = new QPushButton(splitter);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        splitter->addWidget(anuluj_btn);
        splitter_2->addWidget(splitter);
        blad_lbl = new QLabel(edytuj_pracownika);
        blad_lbl->setObjectName(QString::fromUtf8("blad_lbl"));
        blad_lbl->setGeometry(QRect(20, 285, 371, 21));

        retranslateUi(edytuj_pracownika);

        QMetaObject::connectSlotsByName(edytuj_pracownika);
    } // setupUi

    void retranslateUi(QWidget *edytuj_pracownika)
    {
        edytuj_pracownika->setWindowTitle(QCoreApplication::translate("edytuj_pracownika", "edytuj_pracownika", nullptr));
        label_3->setText(QCoreApplication::translate("edytuj_pracownika", "Wybierz dane do modyfikacji:", nullptr));

        const bool __sortingEnabled = dane_do_modyfikacji_list->isSortingEnabled();
        dane_do_modyfikacji_list->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = dane_do_modyfikacji_list->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("edytuj_pracownika", "imie", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = dane_do_modyfikacji_list->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("edytuj_pracownika", "nazwisko", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = dane_do_modyfikacji_list->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("edytuj_pracownika", "haslo", nullptr));
        dane_do_modyfikacji_list->setSortingEnabled(__sortingEnabled);

        label_4->setText(QCoreApplication::translate("edytuj_pracownika", "Podaj nowa wartosc:", nullptr));
        edytuj_btn->setText(QCoreApplication::translate("edytuj_pracownika", "Edytuj", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("edytuj_pracownika", "Anuluj", nullptr));
        blad_lbl->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class edytuj_pracownika: public Ui_edytuj_pracownika {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDYTUJ_PRACOWNIKA_H
