/********************************************************************************
** Form generated from reading UI file 'koszyk.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_KOSZYK_H
#define UI_KOSZYK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_koszyk
{
public:
    QStackedWidget *stackedWidget;
    QWidget *page;
    QPushButton *paragon_btn;
    QPushButton *faktura_btn;
    QWidget *page_3;
    QSplitter *splitter_4;
    QLabel *label_3;
    QLineEdit *imie_txt;
    QLabel *label_2;
    QLineEdit *nazw_txt;
    QLabel *label;
    QLineEdit *nip_txt;
    QSplitter *splitter_3;
    QPushButton *Zatwierdz_klient_btn;
    QPushButton *Anuluj_btn2;
    QLabel *blad_lbl;
    QWidget *page_2;
    QSplitter *splitter_2;
    QTableWidget *produkty_table;
    QSplitter *splitter;
    QPushButton *zatwierdz_btn;
    QPushButton *anuluj_btn;
    QLabel *blad_lbl2;

    void setupUi(QWidget *koszyk)
    {
        if (koszyk->objectName().isEmpty())
            koszyk->setObjectName(QString::fromUtf8("koszyk"));
        koszyk->resize(447, 389);
        stackedWidget = new QStackedWidget(koszyk);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 10, 441, 371));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        paragon_btn = new QPushButton(page);
        paragon_btn->setObjectName(QString::fromUtf8("paragon_btn"));
        paragon_btn->setGeometry(QRect(30, 120, 131, 81));
        faktura_btn = new QPushButton(page);
        faktura_btn->setObjectName(QString::fromUtf8("faktura_btn"));
        faktura_btn->setGeometry(QRect(240, 120, 131, 81));
        stackedWidget->addWidget(page);
        page_3 = new QWidget();
        page_3->setObjectName(QString::fromUtf8("page_3"));
        splitter_4 = new QSplitter(page_3);
        splitter_4->setObjectName(QString::fromUtf8("splitter_4"));
        splitter_4->setGeometry(QRect(10, 30, 421, 191));
        splitter_4->setOrientation(Qt::Vertical);
        label_3 = new QLabel(splitter_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter_4->addWidget(label_3);
        imie_txt = new QLineEdit(splitter_4);
        imie_txt->setObjectName(QString::fromUtf8("imie_txt"));
        splitter_4->addWidget(imie_txt);
        label_2 = new QLabel(splitter_4);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter_4->addWidget(label_2);
        nazw_txt = new QLineEdit(splitter_4);
        nazw_txt->setObjectName(QString::fromUtf8("nazw_txt"));
        splitter_4->addWidget(nazw_txt);
        label = new QLabel(splitter_4);
        label->setObjectName(QString::fromUtf8("label"));
        splitter_4->addWidget(label);
        nip_txt = new QLineEdit(splitter_4);
        nip_txt->setObjectName(QString::fromUtf8("nip_txt"));
        splitter_4->addWidget(nip_txt);
        splitter_3 = new QSplitter(splitter_4);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        Zatwierdz_klient_btn = new QPushButton(splitter_3);
        Zatwierdz_klient_btn->setObjectName(QString::fromUtf8("Zatwierdz_klient_btn"));
        splitter_3->addWidget(Zatwierdz_klient_btn);
        Anuluj_btn2 = new QPushButton(splitter_3);
        Anuluj_btn2->setObjectName(QString::fromUtf8("Anuluj_btn2"));
        splitter_3->addWidget(Anuluj_btn2);
        splitter_4->addWidget(splitter_3);
        blad_lbl = new QLabel(page_3);
        blad_lbl->setObjectName(QString::fromUtf8("blad_lbl"));
        blad_lbl->setGeometry(QRect(20, 230, 401, 16));
        stackedWidget->addWidget(page_3);
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        splitter_2 = new QSplitter(page_2);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setGeometry(QRect(10, 0, 431, 351));
        splitter_2->setOrientation(Qt::Vertical);
        produkty_table = new QTableWidget(splitter_2);
        produkty_table->setObjectName(QString::fromUtf8("produkty_table"));
        splitter_2->addWidget(produkty_table);
        splitter = new QSplitter(splitter_2);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        zatwierdz_btn = new QPushButton(splitter);
        zatwierdz_btn->setObjectName(QString::fromUtf8("zatwierdz_btn"));
        splitter->addWidget(zatwierdz_btn);
        anuluj_btn = new QPushButton(splitter);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        splitter->addWidget(anuluj_btn);
        splitter_2->addWidget(splitter);
        blad_lbl2 = new QLabel(page_2);
        blad_lbl2->setObjectName(QString::fromUtf8("blad_lbl2"));
        blad_lbl2->setGeometry(QRect(10, 350, 421, 20));
        stackedWidget->addWidget(page_2);

        retranslateUi(koszyk);

        stackedWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(koszyk);
    } // setupUi

    void retranslateUi(QWidget *koszyk)
    {
        koszyk->setWindowTitle(QCoreApplication::translate("koszyk", "koszyk", nullptr));
        paragon_btn->setText(QCoreApplication::translate("koszyk", "Paragon", nullptr));
        faktura_btn->setText(QCoreApplication::translate("koszyk", "Faktura", nullptr));
        label_3->setText(QCoreApplication::translate("koszyk", "Imi\304\231", nullptr));
        label_2->setText(QCoreApplication::translate("koszyk", "Nazwisko", nullptr));
        label->setText(QCoreApplication::translate("koszyk", "NIP", nullptr));
        Zatwierdz_klient_btn->setText(QCoreApplication::translate("koszyk", "Zatwierdz", nullptr));
        Anuluj_btn2->setText(QCoreApplication::translate("koszyk", "Anuluj", nullptr));
        blad_lbl->setText(QString());
        zatwierdz_btn->setText(QCoreApplication::translate("koszyk", "Zatwierdz", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("koszyk", "Anuluj", nullptr));
        blad_lbl2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class koszyk: public Ui_koszyk {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_KOSZYK_H
