/********************************************************************************
** Form generated from reading UI file 'dodaj_kategorie.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DODAJ_KATEGORIE_H
#define UI_DODAJ_KATEGORIE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dodaj_kategorie
{
public:
    QSplitter *splitter_7;
    QLabel *label;
    QLineEdit *nazwa_txt;
    QSplitter *splitter_5;
    QLabel *label_2;
    QCheckBox *checkBox;
    QLineEdit *cecha1_txt;
    QSplitter *splitter_4;
    QLabel *label_3;
    QCheckBox *checkBox_2;
    QLineEdit *cecha2_txt;
    QSplitter *splitter_3;
    QLabel *label_4;
    QCheckBox *checkBox_3;
    QLineEdit *cecha3_txt;
    QSplitter *splitter_2;
    QLabel *label_5;
    QCheckBox *checkBox_4;
    QLineEdit *cecha4_txt;
    QSplitter *splitter;
    QLabel *label_6;
    QCheckBox *checkBox_5;
    QLineEdit *cecha5_txt;
    QSplitter *splitter_6;
    QPushButton *dodaj_btn;
    QPushButton *anuluj_btn;

    void setupUi(QWidget *dodaj_kategorie)
    {
        if (dodaj_kategorie->objectName().isEmpty())
            dodaj_kategorie->setObjectName(QString::fromUtf8("dodaj_kategorie"));
        dodaj_kategorie->resize(371, 375);
        splitter_7 = new QSplitter(dodaj_kategorie);
        splitter_7->setObjectName(QString::fromUtf8("splitter_7"));
        splitter_7->setGeometry(QRect(10, 10, 341, 351));
        splitter_7->setOrientation(Qt::Vertical);
        label = new QLabel(splitter_7);
        label->setObjectName(QString::fromUtf8("label"));
        splitter_7->addWidget(label);
        nazwa_txt = new QLineEdit(splitter_7);
        nazwa_txt->setObjectName(QString::fromUtf8("nazwa_txt"));
        splitter_7->addWidget(nazwa_txt);
        splitter_5 = new QSplitter(splitter_7);
        splitter_5->setObjectName(QString::fromUtf8("splitter_5"));
        splitter_5->setOrientation(Qt::Horizontal);
        label_2 = new QLabel(splitter_5);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter_5->addWidget(label_2);
        checkBox = new QCheckBox(splitter_5);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        splitter_5->addWidget(checkBox);
        splitter_7->addWidget(splitter_5);
        cecha1_txt = new QLineEdit(splitter_7);
        cecha1_txt->setObjectName(QString::fromUtf8("cecha1_txt"));
        splitter_7->addWidget(cecha1_txt);
        splitter_4 = new QSplitter(splitter_7);
        splitter_4->setObjectName(QString::fromUtf8("splitter_4"));
        splitter_4->setOrientation(Qt::Horizontal);
        label_3 = new QLabel(splitter_4);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter_4->addWidget(label_3);
        checkBox_2 = new QCheckBox(splitter_4);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        splitter_4->addWidget(checkBox_2);
        splitter_7->addWidget(splitter_4);
        cecha2_txt = new QLineEdit(splitter_7);
        cecha2_txt->setObjectName(QString::fromUtf8("cecha2_txt"));
        splitter_7->addWidget(cecha2_txt);
        splitter_3 = new QSplitter(splitter_7);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setOrientation(Qt::Horizontal);
        label_4 = new QLabel(splitter_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter_3->addWidget(label_4);
        checkBox_3 = new QCheckBox(splitter_3);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        splitter_3->addWidget(checkBox_3);
        splitter_7->addWidget(splitter_3);
        cecha3_txt = new QLineEdit(splitter_7);
        cecha3_txt->setObjectName(QString::fromUtf8("cecha3_txt"));
        splitter_7->addWidget(cecha3_txt);
        splitter_2 = new QSplitter(splitter_7);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        label_5 = new QLabel(splitter_2);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        splitter_2->addWidget(label_5);
        checkBox_4 = new QCheckBox(splitter_2);
        checkBox_4->setObjectName(QString::fromUtf8("checkBox_4"));
        splitter_2->addWidget(checkBox_4);
        splitter_7->addWidget(splitter_2);
        cecha4_txt = new QLineEdit(splitter_7);
        cecha4_txt->setObjectName(QString::fromUtf8("cecha4_txt"));
        splitter_7->addWidget(cecha4_txt);
        splitter = new QSplitter(splitter_7);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        label_6 = new QLabel(splitter);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        splitter->addWidget(label_6);
        checkBox_5 = new QCheckBox(splitter);
        checkBox_5->setObjectName(QString::fromUtf8("checkBox_5"));
        splitter->addWidget(checkBox_5);
        splitter_7->addWidget(splitter);
        cecha5_txt = new QLineEdit(splitter_7);
        cecha5_txt->setObjectName(QString::fromUtf8("cecha5_txt"));
        splitter_7->addWidget(cecha5_txt);
        splitter_6 = new QSplitter(splitter_7);
        splitter_6->setObjectName(QString::fromUtf8("splitter_6"));
        splitter_6->setOrientation(Qt::Horizontal);
        dodaj_btn = new QPushButton(splitter_6);
        dodaj_btn->setObjectName(QString::fromUtf8("dodaj_btn"));
        splitter_6->addWidget(dodaj_btn);
        anuluj_btn = new QPushButton(splitter_6);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        splitter_6->addWidget(anuluj_btn);
        splitter_7->addWidget(splitter_6);

        retranslateUi(dodaj_kategorie);

        QMetaObject::connectSlotsByName(dodaj_kategorie);
    } // setupUi

    void retranslateUi(QWidget *dodaj_kategorie)
    {
        dodaj_kategorie->setWindowTitle(QCoreApplication::translate("dodaj_kategorie", "dodaj_kategorie", nullptr));
        label->setText(QCoreApplication::translate("dodaj_kategorie", "Nazwa", nullptr));
        label_2->setText(QCoreApplication::translate("dodaj_kategorie", "Nazwa Cechy 1", nullptr));
        checkBox->setText(QCoreApplication::translate("dodaj_kategorie", "Parametr Liczbowy", nullptr));
        label_3->setText(QCoreApplication::translate("dodaj_kategorie", "Nazwa Cechy 2", nullptr));
        checkBox_2->setText(QCoreApplication::translate("dodaj_kategorie", "Parametr Liczbowy", nullptr));
        label_4->setText(QCoreApplication::translate("dodaj_kategorie", "Nazwa Cechy 3", nullptr));
        checkBox_3->setText(QCoreApplication::translate("dodaj_kategorie", "Parametr Liczbowy", nullptr));
        label_5->setText(QCoreApplication::translate("dodaj_kategorie", "Nazwa Cechy 4", nullptr));
        checkBox_4->setText(QCoreApplication::translate("dodaj_kategorie", "Parametr Liczbowy", nullptr));
        label_6->setText(QCoreApplication::translate("dodaj_kategorie", "Nazwa Cechy 5", nullptr));
        checkBox_5->setText(QCoreApplication::translate("dodaj_kategorie", "Parametr Liczbowy", nullptr));
        dodaj_btn->setText(QCoreApplication::translate("dodaj_kategorie", "Dodaj", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("dodaj_kategorie", "Anuluj", nullptr));
    } // retranslateUi

};

namespace Ui {
    class dodaj_kategorie: public Ui_dodaj_kategorie {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DODAJ_KATEGORIE_H
