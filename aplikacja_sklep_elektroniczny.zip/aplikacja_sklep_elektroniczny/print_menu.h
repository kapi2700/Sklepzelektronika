#pragma once

void print_menu_wlasciciel();
void print_menu_sprzedawca();
void print_menu_magazynier();
void print_menu_klienci();
void print_menu_produkty_W();
void print_menu_produkty_S();
void print_menu_produkty_M();
void print_menu_transakcje();
void print_menu_pracownicy();