/********************************************************************************
** Form generated from reading UI file 'Sklepzelektronika.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SKLEPZELEKTRONIKA_H
#define UI_SKLEPZELEKTRONIKA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SklepzelektronikaClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *SklepzelektronikaClass)
    {
        if (SklepzelektronikaClass->objectName().isEmpty())
            SklepzelektronikaClass->setObjectName(QString::fromUtf8("SklepzelektronikaClass"));
        SklepzelektronikaClass->resize(600, 400);
        menuBar = new QMenuBar(SklepzelektronikaClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        SklepzelektronikaClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(SklepzelektronikaClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        SklepzelektronikaClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(SklepzelektronikaClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        SklepzelektronikaClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(SklepzelektronikaClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        SklepzelektronikaClass->setStatusBar(statusBar);

        retranslateUi(SklepzelektronikaClass);

        QMetaObject::connectSlotsByName(SklepzelektronikaClass);
    } // setupUi

    void retranslateUi(QMainWindow *SklepzelektronikaClass)
    {
        SklepzelektronikaClass->setWindowTitle(QCoreApplication::translate("SklepzelektronikaClass", "Sklepzelektronika", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SklepzelektronikaClass: public Ui_SklepzelektronikaClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SKLEPZELEKTRONIKA_H
