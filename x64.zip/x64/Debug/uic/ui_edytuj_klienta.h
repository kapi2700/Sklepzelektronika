/********************************************************************************
** Form generated from reading UI file 'edytuj_klienta.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDYTUJ_KLIENTA_H
#define UI_EDYTUJ_KLIENTA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_edytuj_klienta
{
public:
    QTabWidget *tabWidget;
    QWidget *tab_3;
    QSplitter *splitter_3;
    QLabel *label_4;
    QLineEdit *miejsc_lbl;
    QLabel *label_5;
    QLineEdit *dom_lbl;
    QLabel *label_6;
    QLineEdit *miesz_lbl;
    QLabel *label_7;
    QLineEdit *ul_lbl;
    QLabel *label_8;
    QLineEdit *kod_lbl;
    QWidget *tab_4;
    QSplitter *splitter_4;
    QLabel *label_9;
    QLineEdit *kon_txt;
    QLabel *label_10;
    QLineEdit *wew_txt;
    QWidget *tab;
    QSplitter *splitter_5;
    QLabel *label_14;
    QLineEdit *dod_kon_txt;
    QLabel *label_15;
    QLineEdit *dod_wew_txt;
    QWidget *tab_5;
    QSplitter *splitter;
    QLabel *label_11;
    QLineEdit *imie_txt;
    QLabel *label_12;
    QLineEdit *nazwisko_txt;
    QLabel *label_13;
    QLineEdit *nip_txt;
    QLabel *label;
    QLineEdit *email_txt;
    QLabel *label_2;
    QTextEdit *opis_txt;
    QPushButton *potwirdz_btn;
    QPushButton *anuluj_btn;

    void setupUi(QWidget *edytuj_klienta)
    {
        if (edytuj_klienta->objectName().isEmpty())
            edytuj_klienta->setObjectName(QString::fromUtf8("edytuj_klienta"));
        edytuj_klienta->resize(473, 509);
        tabWidget = new QTabWidget(edytuj_klienta);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 471, 431));
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        splitter_3 = new QSplitter(tab_3);
        splitter_3->setObjectName(QString::fromUtf8("splitter_3"));
        splitter_3->setGeometry(QRect(10, 10, 441, 381));
        splitter_3->setOrientation(Qt::Vertical);
        label_4 = new QLabel(splitter_3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter_3->addWidget(label_4);
        miejsc_lbl = new QLineEdit(splitter_3);
        miejsc_lbl->setObjectName(QString::fromUtf8("miejsc_lbl"));
        splitter_3->addWidget(miejsc_lbl);
        label_5 = new QLabel(splitter_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        splitter_3->addWidget(label_5);
        dom_lbl = new QLineEdit(splitter_3);
        dom_lbl->setObjectName(QString::fromUtf8("dom_lbl"));
        splitter_3->addWidget(dom_lbl);
        label_6 = new QLabel(splitter_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        splitter_3->addWidget(label_6);
        miesz_lbl = new QLineEdit(splitter_3);
        miesz_lbl->setObjectName(QString::fromUtf8("miesz_lbl"));
        splitter_3->addWidget(miesz_lbl);
        label_7 = new QLabel(splitter_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        splitter_3->addWidget(label_7);
        ul_lbl = new QLineEdit(splitter_3);
        ul_lbl->setObjectName(QString::fromUtf8("ul_lbl"));
        splitter_3->addWidget(ul_lbl);
        label_8 = new QLabel(splitter_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        splitter_3->addWidget(label_8);
        kod_lbl = new QLineEdit(splitter_3);
        kod_lbl->setObjectName(QString::fromUtf8("kod_lbl"));
        splitter_3->addWidget(kod_lbl);
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        splitter_4 = new QSplitter(tab_4);
        splitter_4->setObjectName(QString::fromUtf8("splitter_4"));
        splitter_4->setGeometry(QRect(10, 40, 441, 141));
        splitter_4->setOrientation(Qt::Vertical);
        label_9 = new QLabel(splitter_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        splitter_4->addWidget(label_9);
        kon_txt = new QLineEdit(splitter_4);
        kon_txt->setObjectName(QString::fromUtf8("kon_txt"));
        splitter_4->addWidget(kon_txt);
        label_10 = new QLabel(splitter_4);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        splitter_4->addWidget(label_10);
        wew_txt = new QLineEdit(splitter_4);
        wew_txt->setObjectName(QString::fromUtf8("wew_txt"));
        splitter_4->addWidget(wew_txt);
        tabWidget->addTab(tab_4, QString());
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        splitter_5 = new QSplitter(tab);
        splitter_5->setObjectName(QString::fromUtf8("splitter_5"));
        splitter_5->setGeometry(QRect(10, 20, 441, 141));
        splitter_5->setOrientation(Qt::Vertical);
        label_14 = new QLabel(splitter_5);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        splitter_5->addWidget(label_14);
        dod_kon_txt = new QLineEdit(splitter_5);
        dod_kon_txt->setObjectName(QString::fromUtf8("dod_kon_txt"));
        splitter_5->addWidget(dod_kon_txt);
        label_15 = new QLabel(splitter_5);
        label_15->setObjectName(QString::fromUtf8("label_15"));
        splitter_5->addWidget(label_15);
        dod_wew_txt = new QLineEdit(splitter_5);
        dod_wew_txt->setObjectName(QString::fromUtf8("dod_wew_txt"));
        splitter_5->addWidget(dod_wew_txt);
        tabWidget->addTab(tab, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        splitter = new QSplitter(tab_5);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(10, 9, 441, 381));
        splitter->setOrientation(Qt::Vertical);
        label_11 = new QLabel(splitter);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        splitter->addWidget(label_11);
        imie_txt = new QLineEdit(splitter);
        imie_txt->setObjectName(QString::fromUtf8("imie_txt"));
        splitter->addWidget(imie_txt);
        label_12 = new QLabel(splitter);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        splitter->addWidget(label_12);
        nazwisko_txt = new QLineEdit(splitter);
        nazwisko_txt->setObjectName(QString::fromUtf8("nazwisko_txt"));
        splitter->addWidget(nazwisko_txt);
        label_13 = new QLabel(splitter);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        splitter->addWidget(label_13);
        nip_txt = new QLineEdit(splitter);
        nip_txt->setObjectName(QString::fromUtf8("nip_txt"));
        splitter->addWidget(nip_txt);
        label = new QLabel(splitter);
        label->setObjectName(QString::fromUtf8("label"));
        splitter->addWidget(label);
        email_txt = new QLineEdit(splitter);
        email_txt->setObjectName(QString::fromUtf8("email_txt"));
        splitter->addWidget(email_txt);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter->addWidget(label_2);
        opis_txt = new QTextEdit(splitter);
        opis_txt->setObjectName(QString::fromUtf8("opis_txt"));
        splitter->addWidget(opis_txt);
        tabWidget->addTab(tab_5, QString());
        potwirdz_btn = new QPushButton(edytuj_klienta);
        potwirdz_btn->setObjectName(QString::fromUtf8("potwirdz_btn"));
        potwirdz_btn->setGeometry(QRect(0, 430, 231, 81));
        anuluj_btn = new QPushButton(edytuj_klienta);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        anuluj_btn->setGeometry(QRect(240, 430, 231, 81));

        retranslateUi(edytuj_klienta);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(edytuj_klienta);
    } // setupUi

    void retranslateUi(QWidget *edytuj_klienta)
    {
        edytuj_klienta->setWindowTitle(QCoreApplication::translate("edytuj_klienta", "edytuj_klienta", nullptr));
        label_4->setText(QCoreApplication::translate("edytuj_klienta", "Miejscowosc", nullptr));
        label_5->setText(QCoreApplication::translate("edytuj_klienta", "numer domu", nullptr));
        label_6->setText(QCoreApplication::translate("edytuj_klienta", "numer mieszkania", nullptr));
        label_7->setText(QCoreApplication::translate("edytuj_klienta", "Ulica", nullptr));
        label_8->setText(QCoreApplication::translate("edytuj_klienta", "kod pocztowy", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("edytuj_klienta", "edytuj adres", nullptr));
        label_9->setText(QCoreApplication::translate("edytuj_klienta", "Telefon", nullptr));
        label_10->setText(QCoreApplication::translate("edytuj_klienta", "Wewnetrzny", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("edytuj_klienta", "edytuj telefon", nullptr));
        label_14->setText(QCoreApplication::translate("edytuj_klienta", "Telefon", nullptr));
        label_15->setText(QCoreApplication::translate("edytuj_klienta", "Wewnetrzny", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("edytuj_klienta", "dodaj telefon", nullptr));
        label_11->setText(QCoreApplication::translate("edytuj_klienta", "Imie", nullptr));
        label_12->setText(QCoreApplication::translate("edytuj_klienta", "Nazwisko", nullptr));
        label_13->setText(QCoreApplication::translate("edytuj_klienta", "NIP", nullptr));
        label->setText(QCoreApplication::translate("edytuj_klienta", "Email", nullptr));
        label_2->setText(QCoreApplication::translate("edytuj_klienta", "Opis", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QCoreApplication::translate("edytuj_klienta", "edytuj personalia", nullptr));
        potwirdz_btn->setText(QCoreApplication::translate("edytuj_klienta", "Potwierdz", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("edytuj_klienta", "Anuluj", nullptr));
    } // retranslateUi

};

namespace Ui {
    class edytuj_klienta: public Ui_edytuj_klienta {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDYTUJ_KLIENTA_H
