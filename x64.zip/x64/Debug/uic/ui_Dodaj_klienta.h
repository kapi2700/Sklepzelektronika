/********************************************************************************
** Form generated from reading UI file 'Dodaj_klienta.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DODAJ_KLIENTA_H
#define UI_DODAJ_KLIENTA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dodaj_klienta
{
public:
    QPushButton *dodaj_btn;
    QPushButton *anuluj_btn;
    QSplitter *splitter;
    QLabel *label;
    QLineEdit *imie_txt;
    QLabel *label_2;
    QLineEdit *nazwisko_txt;
    QLabel *lbl3;
    QLineEdit *email_txt;
    QLabel *lbl4;
    QLineEdit *miejsc_txt;
    QLabel *lbl5;
    QLineEdit *dom_txt;
    QLabel *lbl5_2;
    QLineEdit *mieszkanie_txt;
    QLabel *label_8;
    QLineEdit *ul_txt;
    QLabel *label_6;
    QLineEdit *kod_txt;
    QLabel *label_9;
    QLineEdit *nip_txt;
    QLabel *label_10;
    QLineEdit *kont_txt;
    QLabel *label_11;
    QLineEdit *wew_txt;
    QLabel *label_12;
    QTextEdit *opis_txt;
    QLabel *niepoprawnedane_lbl;

    void setupUi(QWidget *Dodaj_klienta)
    {
        if (Dodaj_klienta->objectName().isEmpty())
            Dodaj_klienta->setObjectName(QString::fromUtf8("Dodaj_klienta"));
        Dodaj_klienta->resize(392, 800);
        dodaj_btn = new QPushButton(Dodaj_klienta);
        dodaj_btn->setObjectName(QString::fromUtf8("dodaj_btn"));
        dodaj_btn->setGeometry(QRect(10, 720, 181, 71));
        anuluj_btn = new QPushButton(Dodaj_klienta);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        anuluj_btn->setGeometry(QRect(204, 720, 181, 71));
        splitter = new QSplitter(Dodaj_klienta);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(10, 10, 371, 701));
        splitter->setOrientation(Qt::Vertical);
        label = new QLabel(splitter);
        label->setObjectName(QString::fromUtf8("label"));
        splitter->addWidget(label);
        imie_txt = new QLineEdit(splitter);
        imie_txt->setObjectName(QString::fromUtf8("imie_txt"));
        splitter->addWidget(imie_txt);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter->addWidget(label_2);
        nazwisko_txt = new QLineEdit(splitter);
        nazwisko_txt->setObjectName(QString::fromUtf8("nazwisko_txt"));
        splitter->addWidget(nazwisko_txt);
        lbl3 = new QLabel(splitter);
        lbl3->setObjectName(QString::fromUtf8("lbl3"));
        splitter->addWidget(lbl3);
        email_txt = new QLineEdit(splitter);
        email_txt->setObjectName(QString::fromUtf8("email_txt"));
        splitter->addWidget(email_txt);
        lbl4 = new QLabel(splitter);
        lbl4->setObjectName(QString::fromUtf8("lbl4"));
        splitter->addWidget(lbl4);
        miejsc_txt = new QLineEdit(splitter);
        miejsc_txt->setObjectName(QString::fromUtf8("miejsc_txt"));
        splitter->addWidget(miejsc_txt);
        lbl5 = new QLabel(splitter);
        lbl5->setObjectName(QString::fromUtf8("lbl5"));
        splitter->addWidget(lbl5);
        dom_txt = new QLineEdit(splitter);
        dom_txt->setObjectName(QString::fromUtf8("dom_txt"));
        splitter->addWidget(dom_txt);
        lbl5_2 = new QLabel(splitter);
        lbl5_2->setObjectName(QString::fromUtf8("lbl5_2"));
        splitter->addWidget(lbl5_2);
        mieszkanie_txt = new QLineEdit(splitter);
        mieszkanie_txt->setObjectName(QString::fromUtf8("mieszkanie_txt"));
        splitter->addWidget(mieszkanie_txt);
        label_8 = new QLabel(splitter);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        splitter->addWidget(label_8);
        ul_txt = new QLineEdit(splitter);
        ul_txt->setObjectName(QString::fromUtf8("ul_txt"));
        splitter->addWidget(ul_txt);
        label_6 = new QLabel(splitter);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        splitter->addWidget(label_6);
        kod_txt = new QLineEdit(splitter);
        kod_txt->setObjectName(QString::fromUtf8("kod_txt"));
        splitter->addWidget(kod_txt);
        label_9 = new QLabel(splitter);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        splitter->addWidget(label_9);
        nip_txt = new QLineEdit(splitter);
        nip_txt->setObjectName(QString::fromUtf8("nip_txt"));
        splitter->addWidget(nip_txt);
        label_10 = new QLabel(splitter);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        splitter->addWidget(label_10);
        kont_txt = new QLineEdit(splitter);
        kont_txt->setObjectName(QString::fromUtf8("kont_txt"));
        splitter->addWidget(kont_txt);
        label_11 = new QLabel(splitter);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        splitter->addWidget(label_11);
        wew_txt = new QLineEdit(splitter);
        wew_txt->setObjectName(QString::fromUtf8("wew_txt"));
        splitter->addWidget(wew_txt);
        label_12 = new QLabel(splitter);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        splitter->addWidget(label_12);
        opis_txt = new QTextEdit(splitter);
        opis_txt->setObjectName(QString::fromUtf8("opis_txt"));
        splitter->addWidget(opis_txt);
        niepoprawnedane_lbl = new QLabel(splitter);
        niepoprawnedane_lbl->setObjectName(QString::fromUtf8("niepoprawnedane_lbl"));
        splitter->addWidget(niepoprawnedane_lbl);

        retranslateUi(Dodaj_klienta);

        QMetaObject::connectSlotsByName(Dodaj_klienta);
    } // setupUi

    void retranslateUi(QWidget *Dodaj_klienta)
    {
        Dodaj_klienta->setWindowTitle(QCoreApplication::translate("Dodaj_klienta", "Dodaj_klienta", nullptr));
        dodaj_btn->setText(QCoreApplication::translate("Dodaj_klienta", "Dodaj", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("Dodaj_klienta", "Anuluj", nullptr));
        label->setText(QCoreApplication::translate("Dodaj_klienta", "Imie", nullptr));
        label_2->setText(QCoreApplication::translate("Dodaj_klienta", "Nazwisko", nullptr));
        lbl3->setText(QCoreApplication::translate("Dodaj_klienta", "Email", nullptr));
        lbl4->setText(QCoreApplication::translate("Dodaj_klienta", "Miejscowo\305\233\304\207", nullptr));
        lbl5->setText(QCoreApplication::translate("Dodaj_klienta", "nr domu", nullptr));
        lbl5_2->setText(QCoreApplication::translate("Dodaj_klienta", "nr mieszkania", nullptr));
        label_8->setText(QCoreApplication::translate("Dodaj_klienta", "Ulica", nullptr));
        label_6->setText(QCoreApplication::translate("Dodaj_klienta", "Kod Pocztowy (5 cyfr)", nullptr));
        label_9->setText(QCoreApplication::translate("Dodaj_klienta", "NIP", nullptr));
        label_10->setText(QCoreApplication::translate("Dodaj_klienta", "Telefon kontaktowy", nullptr));
        label_11->setText(QCoreApplication::translate("Dodaj_klienta", "Telefon wewn\304\231trzny", nullptr));
        label_12->setText(QCoreApplication::translate("Dodaj_klienta", "Opis", nullptr));
        niepoprawnedane_lbl->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Dodaj_klienta: public Ui_Dodaj_klienta {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DODAJ_KLIENTA_H
