/********************************************************************************
** Form generated from reading UI file 'dodaj_pracownika.ui'
**
** Created by: Qt User Interface Compiler version 6.2.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DODAJ_PRACOWNIKA_H
#define UI_DODAJ_PRACOWNIKA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_dodaj_pracownika
{
public:
    QWidget *centralwidget;
    QSplitter *splitter;
    QLabel *label;
    QLineEdit *imie_txt;
    QLabel *label_2;
    QLineEdit *nazwisko_txt;
    QLabel *label_3;
    QLineEdit *login_txt;
    QLabel *label_5;
    QLineEdit *haslo_txt;
    QLabel *label_6;
    QLineEdit *haslo2_txt;
    QLabel *label_4;
    QListWidget *stanowisko_list;
    QSplitter *splitter_2;
    QPushButton *dodaj_btn;
    QPushButton *anuluj_btn;
    QLabel *blad_lbl;

    void setupUi(QWidget *dodaj_pracownika)
    {
        if (dodaj_pracownika->objectName().isEmpty())
            dodaj_pracownika->setObjectName(QString::fromUtf8("dodaj_pracownika"));
        dodaj_pracownika->resize(269, 372);
        centralwidget = new QWidget(dodaj_pracownika);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setGeometry(QRect(0, 0, 251, 371));
        splitter = new QSplitter(centralwidget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(0, 10, 251, 351));
        splitter->setOrientation(Qt::Vertical);
        label = new QLabel(splitter);
        label->setObjectName(QString::fromUtf8("label"));
        splitter->addWidget(label);
        imie_txt = new QLineEdit(splitter);
        imie_txt->setObjectName(QString::fromUtf8("imie_txt"));
        splitter->addWidget(imie_txt);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter->addWidget(label_2);
        nazwisko_txt = new QLineEdit(splitter);
        nazwisko_txt->setObjectName(QString::fromUtf8("nazwisko_txt"));
        splitter->addWidget(nazwisko_txt);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        login_txt = new QLineEdit(splitter);
        login_txt->setObjectName(QString::fromUtf8("login_txt"));
        splitter->addWidget(login_txt);
        label_5 = new QLabel(splitter);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        splitter->addWidget(label_5);
        haslo_txt = new QLineEdit(splitter);
        haslo_txt->setObjectName(QString::fromUtf8("haslo_txt"));
        splitter->addWidget(haslo_txt);
        label_6 = new QLabel(splitter);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        splitter->addWidget(label_6);
        haslo2_txt = new QLineEdit(splitter);
        haslo2_txt->setObjectName(QString::fromUtf8("haslo2_txt"));
        splitter->addWidget(haslo2_txt);
        label_4 = new QLabel(splitter);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter->addWidget(label_4);
        stanowisko_list = new QListWidget(splitter);
        new QListWidgetItem(stanowisko_list);
        new QListWidgetItem(stanowisko_list);
        new QListWidgetItem(stanowisko_list);
        stanowisko_list->setObjectName(QString::fromUtf8("stanowisko_list"));
        splitter->addWidget(stanowisko_list);
        splitter_2 = new QSplitter(splitter);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        dodaj_btn = new QPushButton(splitter_2);
        dodaj_btn->setObjectName(QString::fromUtf8("dodaj_btn"));
        splitter_2->addWidget(dodaj_btn);
        anuluj_btn = new QPushButton(splitter_2);
        anuluj_btn->setObjectName(QString::fromUtf8("anuluj_btn"));
        splitter_2->addWidget(anuluj_btn);
        splitter->addWidget(splitter_2);
        blad_lbl = new QLabel(splitter);
        blad_lbl->setObjectName(QString::fromUtf8("blad_lbl"));
        splitter->addWidget(blad_lbl);

        retranslateUi(dodaj_pracownika);

        QMetaObject::connectSlotsByName(dodaj_pracownika);
    } // setupUi

    void retranslateUi(QWidget *dodaj_pracownika)
    {
        dodaj_pracownika->setWindowTitle(QCoreApplication::translate("dodaj_pracownika", "dodaj_pracownika", nullptr));
        label->setText(QCoreApplication::translate("dodaj_pracownika", "Imi\304\231", nullptr));
        label_2->setText(QCoreApplication::translate("dodaj_pracownika", "Nazwisko", nullptr));
        label_3->setText(QCoreApplication::translate("dodaj_pracownika", "Login", nullptr));
        label_5->setText(QCoreApplication::translate("dodaj_pracownika", "Has\305\202o", nullptr));
        label_6->setText(QCoreApplication::translate("dodaj_pracownika", "Potwierdz Has\305\202o", nullptr));
        label_4->setText(QCoreApplication::translate("dodaj_pracownika", "Stanowisko", nullptr));

        const bool __sortingEnabled = stanowisko_list->isSortingEnabled();
        stanowisko_list->setSortingEnabled(false);
        QListWidgetItem *___qlistwidgetitem = stanowisko_list->item(0);
        ___qlistwidgetitem->setText(QCoreApplication::translate("dodaj_pracownika", "Wlasciciel", nullptr));
        QListWidgetItem *___qlistwidgetitem1 = stanowisko_list->item(1);
        ___qlistwidgetitem1->setText(QCoreApplication::translate("dodaj_pracownika", "Sprzedawca", nullptr));
        QListWidgetItem *___qlistwidgetitem2 = stanowisko_list->item(2);
        ___qlistwidgetitem2->setText(QCoreApplication::translate("dodaj_pracownika", "Magazynier", nullptr));
        stanowisko_list->setSortingEnabled(__sortingEnabled);

        dodaj_btn->setText(QCoreApplication::translate("dodaj_pracownika", "Dodaj", nullptr));
        anuluj_btn->setText(QCoreApplication::translate("dodaj_pracownika", "Anuluj", nullptr));
        blad_lbl->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class dodaj_pracownika: public Ui_dodaj_pracownika {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DODAJ_PRACOWNIKA_H
